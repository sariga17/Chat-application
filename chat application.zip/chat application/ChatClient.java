import java.io.*;
import java.net.*;

public class ChatClient {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 1234;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT)) {
            System.out.println("Connected to the server.");

            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);

            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));


            final String[] serverMessage = new String[1];
            String clientMessage;

            new Thread(() -> {
                try {
                    while ((serverMessage[0] = input.readLine()) != null) {
                        System.out.println("Server: " + serverMessage[0]);
                    }
                } catch (IOException e) {
                    System.out.println("Connection closed.");
                }
            }).start();

            while ((clientMessage = consoleInput.readLine()) != null) {
                output.println(clientMessage);
            }

        } catch (IOException e) {
            System.out.println("Client exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
